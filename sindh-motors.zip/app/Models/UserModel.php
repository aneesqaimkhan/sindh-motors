<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'name', 'fname', 'cnic_no', 'cell_no', 'date_of_birth', 
        'category_id', 'status', 'email', 'username', 'password',
        'is_admin', 'showroom_name', 'showroom_address', 'created_at', 'updated_at'
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    // Validation
    protected $validationRules      = [
        'name' => 'required|min_length[2]|max_length[100]',
        'fname' => 'required|min_length[2]|max_length[100]',
        'cnic_no' => 'required|min_length[13]|max_length[15]',
        'cell_no' => 'required|min_length[11]|max_length[15]',
        'date_of_birth' => 'required|valid_date',
        'email' => 'required|valid_email',
        'username' => 'permit_empty|min_length[3]|max_length[50]',
        'password' => 'permit_empty|min_length[6]',
        'showroom_name' => 'required|min_length[2]|max_length[255]',
        'showroom_address' => 'required|min_length[10]',
    ];
    protected $validationMessages   = [
        'name' => [
            'required' => 'Name is required',
            'min_length' => 'Name must be at least 2 characters long',
            'max_length' => 'Name cannot exceed 100 characters',
        ],
        'fname' => [
            'required' => 'Father\'s name is required',
            'min_length' => 'Father\'s name must be at least 2 characters long',
            'max_length' => 'Father\'s name cannot exceed 100 characters',
        ],
        'cnic_no' => [
            'required' => 'CNIC number is required',
            'min_length' => 'CNIC number must be at least 13 characters long',
            'max_length' => 'CNIC number cannot exceed 15 characters',
            'is_unique' => 'CNIC number already exists',
        ],
        'cell_no' => [
            'required' => 'Cell number is required',
            'min_length' => 'Cell number must be at least 11 characters long',
            'max_length' => 'Cell number cannot exceed 15 characters',
        ],
        'date_of_birth' => [
            'required' => 'Date of birth is required',
            'valid_date' => 'Please enter a valid date',
        ],
        'email' => [
            'required' => 'Email is required',
            'valid_email' => 'Please enter a valid email address',
            'is_unique' => 'Email already exists',
        ],
        'username' => [
            'min_length' => 'Username must be at least 3 characters long',
            'max_length' => 'Username cannot exceed 50 characters',
            'is_unique' => 'Username already exists',
        ],
        'password' => [
            'min_length' => 'Password must be at least 6 characters long',
        ],
        'showroom_name' => [
            'required' => 'Showroom name is required',
            'min_length' => 'Showroom name must be at least 2 characters long',
            'max_length' => 'Showroom name cannot exceed 255 characters',
        ],
        'showroom_address' => [
            'required' => 'Showroom address is required',
            'min_length' => 'Showroom address must be at least 10 characters long',
        ],
    ];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = ['hashPassword'];
    protected $beforeUpdate   = ['hashPassword'];

    protected function hashPassword(array $data)
    {
        if (!isset($data['data']['password'])) {
            return $data;
        }

        $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);
        return $data;
    }

    public function authenticate($username, $password)
    {
        $user = $this->where('username', $username)
                    ->orWhere('email', $username)
                    ->first();

        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }

        return false;
    }

    public function getActiveUsers()
    {
        return $this->where('status', 'active')->findAll();
    }

    public function getUserById($id)
    {
        return $this->find($id);
    }

    public function updateUserStatus($id, $status)
    {
        return $this->update($id, ['status' => $status]);
    }

    public function getPendingUsers()
    {
        return $this->where('status', 'pending')->findAll();
    }

    public function getAdminUsers()
    {
        return $this->where('is_admin', 1)->findAll();
    }

    public function isAdmin($userId)
    {
        $user = $this->find($userId);
        return $user && $user['is_admin'] == 1;
    }

    public function approveUser($id)
    {
        return $this->update($id, ['status' => 'active']);
    }

    public function rejectUser($id)
    {
        return $this->update($id, ['status' => 'inactive']);
    }

    public function getUsersWithMembers()
    {
        return $this->select('users.*, COUNT(members.id) as member_count')
                    ->join('members', 'members.user_id = users.id', 'left')
                    ->groupBy('users.id, users.name, users.fname, users.cnic_no, users.cell_no, users.date_of_birth, users.category_id, users.status, users.email, users.username, users.password, users.is_admin, users.showroom_name, users.showroom_address, users.created_at, users.updated_at')
                    ->findAll();
    }

    public function updateUser($id, $data)
    {
        // Remove any fields that shouldn't be updated
        unset($data['created_at']);
        unset($data['updated_at']);
        
        // If password is empty, don't update it
        if (empty($data['password'])) {
            unset($data['password']);
        }
        
        // If username is empty, don't update it
        if (empty($data['username'])) {
            unset($data['username']);
        }
        
        $data['id'] = $id;
        
        // Temporarily disable validation for update
        $this->skipValidation(true);
        
        $result = $this->save($data);
        
        // Re-enable validation
        $this->skipValidation(false);
        
        return $result;
    }

    public function getAllUsersWithMembers()
    {
        return $this->select('users.*, COUNT(members.id) as member_count')
                    ->join('members', 'members.user_id = users.id', 'left')
                    ->groupBy('users.id, users.name, users.fname, users.cnic_no, users.cell_no, users.date_of_birth, users.category_id, users.status, users.email, users.username, users.password, users.is_admin, users.showroom_name, users.showroom_address, users.created_at, users.updated_at')
                    ->orderBy('users.created_at', 'DESC')
                    ->findAll();
    }
}
