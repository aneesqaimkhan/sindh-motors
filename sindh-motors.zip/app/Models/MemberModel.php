<?php

namespace App\Models;

use CodeIgniter\Model;

class MemberModel extends Model
{
    protected $table            = 'members';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'member_name', 'father_name', 'cnic_no', 'cell_no', 'profile_picture', 'status', 'user_id', 'created_at', 'updated_at'
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    // Validation
    protected $validationRules      = [
        'member_name' => 'required|min_length[2]|max_length[100]',
        'father_name' => 'required|min_length[2]|max_length[100]',
        'cnic_no' => 'required|min_length[13]|max_length[15]',
        'cell_no' => 'required|min_length[11]|max_length[15]',
        'profile_picture' => 'permit_empty',
    ];
    protected $validationMessages   = [
        'member_name' => [
            'required' => 'Member name is required',
            'min_length' => 'Member name must be at least 2 characters long',
            'max_length' => 'Member name cannot exceed 100 characters',
        ],
        'father_name' => [
            'required' => 'Father\'s name is required',
            'min_length' => 'Father\'s name must be at least 2 characters long',
            'max_length' => 'Father\'s name cannot exceed 100 characters',
        ],
        'cnic_no' => [
            'required' => 'CNIC number is required',
            'min_length' => 'CNIC number must be at least 13 characters long',
            'max_length' => 'CNIC number cannot exceed 15 characters',
        ],
        'cell_no' => [
            'required' => 'Cell number is required',
            'min_length' => 'Cell number must be at least 11 characters long',
            'max_length' => 'Cell number cannot exceed 15 characters',
        ],

    ];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    public function getActiveMembers()
    {
        return $this->where('status', 'active')->findAll();
    }

    public function getMemberById($id)
    {
        return $this->find($id);
    }

    public function updateMemberStatus($id, $status)
    {
        return $this->update($id, ['status' => $status]);
    }

    public function getTotalMembers()
    {
        return $this->countAll();
    }

    public function getActiveMembersCount()
    {
        return $this->where('status', 'active')->countAllResults();
    }

    public function getMembersByUserId($userId)
    {
        return $this->where('user_id', $userId)->findAll();
    }

    public function addMember($data)
    {
        // Remove any fields that shouldn't be set for new members
        unset($data['id']);
        unset($data['created_at']);
        unset($data['updated_at']);
        
        // Temporarily disable validation for new member
        $this->skipValidation(true);
        
        $result = $this->save($data);
        
        // Re-enable validation
        $this->skipValidation(false);
        
        return $result;
    }

    public function updateMember($id, $data)
    {
        // Remove any fields that shouldn't be updated
        unset($data['created_at']);
        unset($data['updated_at']);
        
        $data['id'] = $id;
        
        // Temporarily disable validation for update
        $this->skipValidation(true);
        
        $result = $this->save($data);
        
        // Re-enable validation
        $this->skipValidation(false);
        
        return $result;
    }

    public function saveMultipleMembers($members, $userId)
    {
        $savedMembers = [];
        foreach ($members as $member) {
            $member['user_id'] = $userId;
            if ($this->save($member)) {
                $savedMembers[] = $this->insertID;
            }
        }
        return $savedMembers;
    }
}


