<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\MemberModel;

class Auth extends BaseController
{
    protected $userModel;
    protected $memberModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->memberModel = new MemberModel();
    }

    public function index()
    {
        // Redirect to landing page
        return redirect()->to('/');
    }

    public function login()
    {
        if ($this->request->getMethod() === 'post') {
            $username = $this->request->getPost('username');
            $password = $this->request->getPost('password');

            log_message('debug', 'Login attempt for username: ' . $username);

            $user = $this->userModel->authenticate($username, $password);

            if ($user) {
                log_message('debug', 'User authenticated successfully: ' . json_encode($user));
                
                // Check if user account is approved
                if ($user['status'] === 'pending') {
                    log_message('debug', 'User account is pending approval');
                    return redirect()->back()->with('error', 'Your account is pending admin approval. Please wait for approval before logging in.');
                }

                if ($user['status'] === 'inactive') {
                    log_message('debug', 'User account is inactive');
                    return redirect()->back()->with('error', 'Your account has been deactivated. Please contact administrator.');
                }

                // Set session data
                session()->set([
                    'user_id' => $user['id'],
                    'username' => $user['username'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'is_admin' => $user['is_admin'],
                    'logged_in' => true
                ]);

                log_message('debug', 'Session data set: ' . json_encode(session()->get()));
                
                // Verify session was set correctly
                if (!session()->get('logged_in') || !session()->get('user_id')) {
                    log_message('error', 'Session data not set correctly after login');
                    return redirect()->back()->with('error', 'Session error. Please try again.');
                }

                // Redirect admin users to admin panel
                if ($user['is_admin'] == 1) {
                    log_message('debug', 'Redirecting admin user to admin panel');
                    return redirect()->to('admin/')->with('success', 'Admin login successful!');
                }

                log_message('debug', 'Redirecting regular user to admin panel');
                return redirect()->to('admin/')->with('success', 'Login successful!');
            } else {
                log_message('debug', 'Authentication failed for username: ' . $username);
                return redirect()->back()->with('error', 'Invalid username or password');
            }
        }

        return view('auth/login');
    }

    public function register()
    {
        if ($this->request->getMethod() === 'post') {
            log_message('debug', 'Register POST request received');
            log_message('debug', 'POST data: ' . json_encode($this->request->getPost()));
            log_message('debug', 'FILES data: ' . json_encode($this->request->getFiles()));
            
            // Check database connection
            try {
                $db = \Config\Database::connect();
                $db->connect();
                log_message('debug', 'Database connection successful');
                
                // Test a simple query
                $testResult = $db->query('SELECT 1 as test');
                if (!$testResult) {
                    throw new \Exception('Database query test failed');
                }
                log_message('debug', 'Database query test successful');
                
            } catch (\Exception $e) {
                log_message('error', 'Database connection failed: ' . $e->getMessage());
                return redirect()->back()
                    ->withInput()
                    ->with('error', 'Database connection failed. Please try again later.');
            }
            
            $data = [
                'name' => $this->request->getPost('name'),
                'fname' => $this->request->getPost('fname'),
                'cnic_no' => $this->request->getPost('cnic_no'),
                'cell_no' => $this->request->getPost('cell_no'),
                'date_of_birth' => $this->request->getPost('date_of_birth'),
                'category_id' => $this->request->getPost('category_id') ?: null,
                'status' => 'pending', // Set status to pending for admin approval
                'email' => $this->request->getPost('email'),
                'username' => $this->generateUniqueUsername($this->request->getPost('name'), $this->request->getPost('email')),
                'password' => $this->generateRandomPassword(),
                'showroom_name' => $this->request->getPost('showroom_name'),
                'showroom_address' => $this->request->getPost('showroom_address'),
                'is_admin' => 0, // Regular users are not admins
            ];
            
            log_message('debug', 'User data to save: ' . json_encode($data));

            // Start database transaction
            $db = \Config\Database::connect();
            $db->transStart();

            try {
                // Save user
                log_message('debug', 'Attempting to save user with data: ' . json_encode($data));
                
                // Check if username already exists
                $existingUser = $this->userModel->where('username', $data['username'])->first();
                if ($existingUser) {
                    log_message('error', 'Username already exists: ' . $data['username']);
                    throw new \Exception('Username already exists. Please try again.');
                }
                
                if (!$this->userModel->save($data)) {
                    $errors = $this->userModel->errors();
                    log_message('error', 'User save errors: ' . json_encode($errors));
                    throw new \Exception('Failed to save user data: ' . implode(', ', $errors));
                }

                $userId = $this->userModel->insertID;
                log_message('debug', 'User saved successfully with ID: ' . $userId);

                // Handle membership data
                $members = $this->request->getPost('members');
                log_message('debug', 'Members data received: ' . json_encode($members));
                if ($members && is_array($members)) {
                    foreach ($members as $index => $memberData) {
                        log_message('debug', 'Processing member ' . $index . ': ' . json_encode($memberData));
                        if (!empty($memberData['member_name']) && !empty($memberData['father_name'])) {
                            $member = [
                                'member_name' => $memberData['member_name'],
                                'father_name' => $memberData['father_name'],
                                'cnic_no' => $memberData['cnic_no'],
                                'cell_no' => $memberData['cell_no'],
                                'user_id' => $userId,
                                'status' => 'active'
                            ];

                            // Handle profile picture upload
                            $profilePicture = $this->request->getFile("members.{$index}.profile_picture");
                            if ($profilePicture && $profilePicture->isValid() && !$profilePicture->hasMoved()) {
                                // Create uploads directory if it doesn't exist
                                $uploadPath = ROOTPATH . 'public/uploads/members';
                                if (!is_dir($uploadPath)) {
                                    mkdir($uploadPath, 0777, true);
                                }
                                
                                $newName = $profilePicture->getRandomName();
                                if ($profilePicture->move($uploadPath, $newName)) {
                                    $member['profile_picture'] = $newName;
                                }
                            }

                            log_message('debug', 'Saving member: ' . json_encode($member));
                            if (!$this->memberModel->save($member)) {
                                $errors = $this->memberModel->errors();
                                log_message('error', 'Member save errors: ' . json_encode($errors));
                                throw new \Exception('Failed to save member data: ' . implode(', ', $errors));
                            }
                        }
                    }
                }

                $db->transComplete();

                if ($db->transStatus() === false) {
                    log_message('error', 'Database transaction failed');
                    throw new \Exception('Database transaction failed');
                }
                
                log_message('debug', 'Database transaction completed successfully');

                return redirect()->to('/')->with('success', 'Showroom Record Added Successfully');

            } catch (\Exception $e) {
                $db->transRollback();
                log_message('error', 'Registration failed: ' . $e->getMessage());
                return redirect()->back()
                    ->withInput()
                    ->with('error', 'Registration failed: ' . $e->getMessage());
            }
        }

        return view('auth/register');
    }

    /**
     * Generate a unique username based on name and email
     */
    private function generateUniqueUsername($name, $email)
    {
        // Extract username from email (part before @)
        $emailUsername = explode('@', $email)[0];
        
        // Clean the name for username
        $cleanName = preg_replace('/[^a-zA-Z0-9]/', '', strtolower($name));
        
        // Ensure minimum length
        if (strlen($cleanName) < 3) {
            $cleanName = $cleanName . 'user';
        }
        
        // Try different combinations
        $attempts = [
            $cleanName,
            $emailUsername,
            $cleanName . rand(100, 999),
            $emailUsername . rand(100, 999),
            $cleanName . '_' . $emailUsername,
            $cleanName . '_' . date('y'),
        ];
        
        foreach ($attempts as $username) {
            // Ensure username meets requirements
            if (strlen($username) >= 3 && strlen($username) <= 50) {
                $existingUser = $this->userModel->where('username', $username)->first();
                if (!$existingUser) {
                    log_message('debug', 'Generated unique username: ' . $username);
                    return $username;
                }
            }
        }
        
        // If all attempts fail, generate a random username
        do {
            $username = 'user_' . rand(100000, 999999);
        } while ($this->userModel->where('username', $username)->first());
        
        log_message('debug', 'Generated fallback username: ' . $username);
        return $username;
    }

    /**
     * Generate a random password for new users
     */
    private function generateRandomPassword()
    {
        $length = 12;
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
        $password = '';
        
        for ($i = 0; $i < $length; $i++) {
            $password .= $chars[rand(0, strlen($chars) - 1)];
        }
        
        return $password;
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/')->with('success', 'Logout successful!');
    }

    public function dashboard()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('admin/login');
        }

        $data = [
            'title' => 'Dashboard',
            'user' => [
                'name' => session()->get('name'),
                'username' => session()->get('username'),
                'email' => session()->get('email')
            ]
        ];

        return view('dashboard/index', $data);
    }
}
