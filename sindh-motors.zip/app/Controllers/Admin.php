<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\MemberModel;

class Admin extends BaseController
{
    protected $userModel;
    protected $memberModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->memberModel = new MemberModel();
    }

    public function index()
    {
        log_message('debug', 'Admin index method called');
        log_message('debug', 'Session data: ' . json_encode(session()->get()));
        
        // Check if user is logged in
        if (!session()->get('logged_in')) {
            log_message('debug', 'User not logged in, redirecting to login');
            return redirect()->to('admin/login')->with('error', 'Please login to access admin panel');
        }
        
        // Check if user is admin
        if (!session()->get('is_admin')) {
            log_message('debug', 'User is not admin, redirecting to login');
            return redirect()->to('admin/login')->with('error', 'Access denied. Admin privileges required.');
        }

        // Verify user still exists in database and has admin privileges
        $userId = session()->get('user_id');
        $currentUser = $this->userModel->find($userId);
        
        if (!$currentUser) {
            log_message('error', 'User not found in database, clearing session');
            session()->destroy();
            return redirect()->to('admin/login')->with('error', 'User account not found. Please login again.');
        }
        
        if ($currentUser['is_admin'] != 1) {
            log_message('error', 'User admin privileges revoked, clearing session');
            session()->destroy();
            return redirect()->to('admin/login')->with('error', 'Admin privileges revoked. Please contact administrator.');
        }
        
        if ($currentUser['status'] !== 'active') {
            log_message('error', 'User account not active, clearing session');
            session()->destroy();
            return redirect()->to('admin/login')->with('error', 'Account not active. Please contact administrator.');
        }

        log_message('debug', 'User authenticated, loading admin dashboard');

        try {
            $data = [
                'title' => 'Admin Dashboard',
                'users' => $this->userModel->getAllUsersWithMembers(),
                'total_users' => $this->userModel->countAll(),
                'active_users' => $this->userModel->where('status', 'active')->countAllResults(),
                'pending_users' => $this->userModel->where('status', 'pending')->countAllResults(),
            ];

            return view('admin/dashboard', $data);
        } catch (Exception $e) {
            log_message('error', 'Error loading admin dashboard: ' . $e->getMessage());
            return redirect()->to('admin/login')->with('error', 'Error loading dashboard: ' . $e->getMessage());
        }
    }

    public function users()
    {
        if (!session()->get('logged_in') || !session()->get('is_admin')) {
            return redirect()->to('admin/login');
        }

        $data = [
            'title' => 'User Management',
            'users' => $this->userModel->getUsersWithMembers(),
        ];

        return view('admin/users', $data);
    }

    public function addUser()
    {
        if (!session()->get('logged_in') || !session()->get('is_admin')) {
            return redirect()->to('admin/login');
        }

        if ($this->request->getMethod() === 'post') {
            $data = [
                'name' => $this->request->getPost('name'),
                'fname' => $this->request->getPost('fname'),
                'cnic_no' => $this->request->getPost('cnic_no'),
                'cell_no' => $this->request->getPost('cell_no'),
                'date_of_birth' => $this->request->getPost('date_of_birth'),
                'category_id' => $this->request->getPost('category_id') ?: null,
                'status' => $this->request->getPost('status') ?: 'active',
                'email' => $this->request->getPost('email'),
                'username' => $this->request->getPost('username'),
                'password' => $this->request->getPost('password'),
                'showroom_name' => $this->request->getPost('showroom_name'),
                'showroom_address' => $this->request->getPost('showroom_address'),
                'is_admin' => 0,
            ];

            if ($this->userModel->save($data)) {
                return redirect()->to('admin/users')->with('success', 'User added successfully!');
            } else {
                return redirect()->back()
                    ->withInput()
                    ->with('errors', $this->userModel->errors());
            }
        }

        $data = [
            'title' => 'Add New User',
        ];

        return view('admin/add_user', $data);
    }



    public function testEdit($id = null)
    {
        log_message('debug', 'TestEdit method called with ID: ' . $id);
        
        $data = [
            'title' => 'Test Edit',
            'user' => [
                'id' => $id,
                'name' => 'Test User',
                'email' => 'test@example.com'
            ],
        ];

        log_message('debug', 'Test data: ' . json_encode($data));

        return view('admin/edit_user', $data);
    }

    public function testUpdate($id = null)
    {
        log_message('debug', 'TestUpdate method called with ID: ' . $id);
        
        if ($this->request->getMethod() === 'post') {
            $postData = $this->request->getPost();
            log_message('debug', 'Test POST data: ' . json_encode($postData));
            
            // Simple test update
            $testData = [
                'id' => $id,
                'name' => $this->request->getPost('name'),
                'email' => $this->request->getPost('email'),
            ];
            
            log_message('debug', 'Test update data: ' . json_encode($testData));
            
            if ($this->userModel->updateUser($id, $testData)) {
                log_message('debug', 'Test update successful');
                return redirect()->to('admin/users')->with('success', 'Test update successful!');
            } else {
                log_message('error', 'Test update failed: ' . json_encode($this->userModel->errors()));
                return redirect()->back()->with('error', 'Test update failed');
            }
        }
        
        return redirect()->to('admin/users');
    }

    public function testDatabase()
    {
        log_message('debug', 'Testing database connection...');
        
        try {
            $db = \Config\Database::connect();
            $result = $db->query('SELECT 1 as test')->getRow();
            log_message('debug', 'Database test result: ' . json_encode($result));
            
            // Test user table
            $userResult = $db->query('SELECT COUNT(*) as count FROM users')->getRow();
            log_message('debug', 'Users table count: ' . json_encode($userResult));
            
            // Test members table
            $memberResult = $db->query('SELECT COUNT(*) as count FROM members')->getRow();
            log_message('debug', 'Members table count: ' . json_encode($memberResult));
            
            return $this->response->setJSON([
                'success' => true,
                'database' => 'Connected',
                'users_count' => $userResult->count,
                'members_count' => $memberResult->count
            ]);
        } catch (Exception $e) {
            log_message('error', 'Database test failed: ' . $e->getMessage());
            return $this->response->setJSON([
                'success' => false,
                'error' => $e->getMessage()
            ]);
        }
    }

    public function editUser($id = null)
    {
        
        log_message('debug', 'EditUser method called with ID: ' . $id);
        
        if (!session()->get('logged_in') || !session()->get('is_admin')) {
            log_message('debug', 'User not logged in or not admin');
            return redirect()->to('admin/login');
        }

        if (!$id) {
            log_message('debug', 'No user ID provided');
            return redirect()->to('admin/users')->with('error', 'User ID is required');
        }

        // Validate that ID is a number
        if (!is_numeric($id)) {
            log_message('debug', 'Invalid user ID format: ' . $id);
            return redirect()->to('admin/users')->with('error', 'Invalid user ID format');
        }

        log_message('debug', 'Attempting to find user with ID: ' . $id);
        
        try {
            $user = $this->userModel->find($id);
            // Also fetch members for this user
            $members = $this->memberModel->getMembersByUserId($id);
        } catch (Exception $e) {
            log_message('error', 'Database error finding user: ' . $e->getMessage());
            return redirect()->to('admin/users')->with('error', 'Database error: ' . $e->getMessage());
        }
        
        if (!$user) {
            log_message('debug', 'User not found in database');
            return redirect()->to('admin/users')->with('error', 'User not found');
        }

        log_message('debug', 'Edit user data: ' . json_encode($user));
        log_message('debug', 'Edit members data: ' . json_encode($members));

        if ($this->request->getMethod() === 'post') {
            log_message('debug', 'Processing POST request for user edit');
            
            // Get all POST data for debugging
            $postData = $this->request->getPost();
            log_message('debug', 'POST data received: ' . json_encode($postData));
            
            // Update user data - only include fields that exist in the database
            $userData = [
                'id' => $id,
                'name' => $this->request->getPost('name'),
                'fname' => $this->request->getPost('fname'),
                'cnic_no' => $this->request->getPost('cnic_no'),
                'cell_no' => $this->request->getPost('cell_no'),
                'date_of_birth' => $this->request->getPost('date_of_birth'),
                'category_id' => $this->request->getPost('category_id') ?: null,
                'status' => $this->request->getPost('status'),
                'email' => $this->request->getPost('email'),
                'showroom_name' => $this->request->getPost('showroom_name'),
                'showroom_address' => $this->request->getPost('showroom_address'),
            ];

            log_message('debug', 'User data to update: ' . json_encode($userData));

            // Update user
            try {
                // Use the safer update method
                if ($this->userModel->updateUser($id, $userData)) {
                    log_message('debug', 'User updated successfully');
                    
                    // Handle members update
                    $membersData = $this->request->getPost('members');
                    log_message('debug', 'Members data received: ' . json_encode($membersData));
                    
                    if ($membersData && is_array($membersData)) {
                        // Filter out empty member entries
                        $membersData = array_filter($membersData, function($member) {
                            return !empty($member['member_name']) && !empty($member['father_name']) && 
                                   !empty($member['cnic_no']) && !empty($member['cell_no']);
                        });
                        
                        // Get existing member IDs for this user
                        $existingMemberIds = array_column($members, 'id');
                        $updatedMemberIds = [];
                        
                        foreach ($membersData as $memberIndex => $memberData) {
                            log_message('debug', 'Processing member ' . $memberIndex . ': ' . json_encode($memberData));
                            
                            if (isset($memberData['id']) && !empty($memberData['id'])) {
                                // Update existing member
                                $updateData = [
                                    'member_name' => $memberData['member_name'],
                                    'father_name' => $memberData['father_name'],
                                    'cnic_no' => $memberData['cnic_no'],
                                    'cell_no' => $memberData['cell_no'],
                                    'status' => $memberData['status'] ?? 'active',
                                ];
                                
                                $updatedMemberIds[] = $memberData['id'];
                                log_message('debug', 'Updating existing member: ' . json_encode($updateData));
                                
                                // Handle profile picture upload for existing member
                                $profilePicture = $this->request->getFile('members.' . $memberIndex . '.profile_picture');
                                if ($profilePicture && $profilePicture->isValid() && !$profilePicture->hasMoved()) {
                                    $uploadPath = ROOTPATH . 'public/uploads/members';
                                    if (!is_dir($uploadPath)) {
                                        mkdir($uploadPath, 0777, true);
                                    }
                                    
                                    $newName = $profilePicture->getRandomName();
                                    if ($profilePicture->move($uploadPath, $newName)) {
                                        $updateData['profile_picture'] = $newName;
                                        log_message('debug', 'Profile picture uploaded: ' . $newName);
                                    }
                                }
                                
                                // Temporarily disable validation for member update
                                $this->memberModel->skipValidation(true);
                                if ($this->memberModel->updateMember($memberData['id'], $updateData)) {
                                    log_message('debug', 'Member updated successfully: ' . $memberData['id']);
                                } else {
                                    log_message('error', 'Failed to update member: ' . json_encode($this->memberModel->errors()));
                                }
                                $this->memberModel->skipValidation(false);
                            } else {
                                // Add new member
                                $newMemberData = [
                                    'member_name' => $memberData['member_name'],
                                    'father_name' => $memberData['father_name'],
                                    'cnic_no' => $memberData['cnic_no'],
                                    'cell_no' => $memberData['cell_no'],
                                    'status' => $memberData['status'] ?? 'active',
                                    'user_id' => $id,
                                ];
                                
                                log_message('debug', 'Adding new member: ' . json_encode($newMemberData));
                                
                                // Handle profile picture upload for new member
                                $profilePicture = $this->request->getFile('members.' . $memberIndex . '.profile_picture');
                                if ($profilePicture && $profilePicture->isValid() && !$profilePicture->hasMoved()) {
                                    $uploadPath = ROOTPATH . 'public/uploads/members';
                                    if (!is_dir($uploadPath)) {
                                        mkdir($uploadPath, 0777, true);
                                    }
                                    
                                    $newName = $profilePicture->getRandomName();
                                    if ($profilePicture->move($uploadPath, $newName)) {
                                        $newMemberData['profile_picture'] = $newName;
                                        log_message('debug', 'New member profile picture uploaded: ' . $newName);
                                    }
                                }
                                
                                // Temporarily disable validation for new member
                                $this->memberModel->skipValidation(true);
                                if ($this->memberModel->addMember($newMemberData)) {
                                    log_message('debug', 'New member added successfully');
                                } else {
                                    log_message('error', 'Failed to add new member: ' . json_encode($this->memberModel->errors()));
                                }
                                $this->memberModel->skipValidation(false);
                            }
                        }
                        
                        // Delete members that were removed from the form
                        $membersToDelete = array_diff($existingMemberIds, $updatedMemberIds);
                        foreach ($membersToDelete as $memberId) {
                            if ($this->memberModel->delete($memberId)) {
                                log_message('debug', 'Member deleted successfully: ' . $memberId);
                            } else {
                                log_message('error', 'Failed to delete member: ' . $memberId);
                            }
                        }
                    } else {
                        // If no members submitted, delete all existing members for this user
                        if (!empty($members)) {
                            foreach ($members as $member) {
                                if ($this->memberModel->delete($member['id'])) {
                                    log_message('debug', 'Member deleted (no members submitted): ' . $member['id']);
                                } else {
                                    log_message('error', 'Failed to delete member: ' . $member['id']);
                                }
                            }
                        }
                    }
                    
                    return redirect()->to('admin/users')->with('success', 'User and members updated successfully!');
                } else {
                    log_message('error', 'Failed to update user: ' . json_encode($this->userModel->errors()));
                    return redirect()->back()
                        ->withInput()
                        ->with('errors', $this->userModel->errors());
                }
            } catch (Exception $e) {
                log_message('error', 'Exception during user update: ' . $e->getMessage());
                log_message('error', 'Exception trace: ' . $e->getTraceAsString());
                return redirect()->back()
                    ->withInput()
                    ->with('error', 'Error updating user: ' . $e->getMessage());
            }
        }

        $data = [
            'title' => 'Edit User',
            'user' => $user,
            'members' => $members,
        ];

        log_message('debug', 'Rendering edit user view with data: ' . json_encode($data));

        return view('admin/edit_user', $data);
    }

    public function deleteUser($id = null)
    {
        if (!session()->get('logged_in') || !session()->get('is_admin')) {
            return redirect()->to('admin/login');
        }

        if (!$id) {
            return redirect()->to('admin/users')->with('error', 'User ID is required');
        }

        if ($this->userModel->delete($id)) {
            return redirect()->to('admin/users')->with('success', 'User deleted successfully!');
        } else {
            return redirect()->to('admin/users')->with('error', 'Failed to delete user');
        }
    }

    public function toggleStatus($id = null)
    {
        if (!session()->get('logged_in') || !session()->get('is_admin')) {
            return redirect()->to('admin/login');
        }

        if (!$id) {
            return redirect()->to('admin/users')->with('error', 'User ID is required');
        }

        $user = $this->userModel->find($id);
        if (!$user) {
            return redirect()->to('admin/users')->with('error', 'User not found');
        }

        $newStatus = $user['status'] === 'active' ? 'inactive' : 'active';
        
        if ($this->userModel->updateUserStatus($id, $newStatus)) {
            return redirect()->to('admin/users')->with('success', 'User status updated successfully!');
        } else {
            return redirect()->to('admin/users')->with('error', 'Failed to update user status');
        }
    }

    public function approveUser($id = null)
    {
        if (!session()->get('logged_in') || !session()->get('is_admin')) {
            return redirect()->to('admin/login');
        }

        if (!$id) {
            return redirect()->to('admin/users')->with('error', 'User ID is required');
        }

        if ($this->userModel->approveUser($id)) {
            return redirect()->to('admin/users')->with('success', 'User approved successfully!');
        } else {
            return redirect()->to('admin/users')->with('error', 'Failed to approve user');
        }
    }

    public function rejectUser($id = null)
    {
        if (!session()->get('logged_in') || !session()->get('is_admin')) {
            return redirect()->to('admin/login');
        }

        if (!$id) {
            return redirect()->to('admin/users')->with('error', 'User ID is required');
        }

        if ($this->userModel->rejectUser($id)) {
            return redirect()->to('admin/users')->with('success', 'User rejected successfully!');
        } else {
            return redirect()->to('admin/users')->with('error', 'Failed to reject user');
        }
    }

    public function viewUserDetails($id = null)
    {
        if (!session()->get('logged_in') || !session()->get('is_admin')) {
            return redirect()->to('admin/login');
        }

        if (!$id) {
            return redirect()->to('admin/users')->with('error', 'User ID is required');
        }

        $user = $this->userModel->find($id);
        if (!$user) {
            return redirect()->to('admin/users')->with('error', 'User not found');
        }

        $members = $this->memberModel->getMembersByUserId($id);

        $data = [
            'title' => 'User Details',
            'user' => $user,
            'members' => $members,
        ];

        return view('admin/user_details', $data);
    }

    public function pendingUsers()
    {
        if (!session()->get('logged_in') || !session()->get('is_admin')) {
            return redirect()->to('admin/login');
        }

        $data = [
            'title' => 'Pending Approvals',
            'users' => $this->userModel->getPendingUsers(),
        ];

        return view('admin/pending_users', $data);
    }

    // Membership Management Methods
    public function getMember($id = null)
    {
        if (!session()->get('logged_in') || !session()->get('is_admin')) {
            return $this->response->setJSON(['success' => false, 'message' => 'Unauthorized access']);
        }

        if (!$id) {
            return $this->response->setJSON(['success' => false, 'message' => 'Member ID is required']);
        }

        $member = $this->memberModel->find($id);
        if (!$member) {
            return $this->response->setJSON(['success' => false, 'message' => 'Member not found']);
        }

        return $this->response->setJSON(['success' => true, 'member' => $member]);
    }

    public function addMember()
    {
        if (!session()->get('logged_in') || !session()->get('is_admin')) {
            return $this->response->setJSON(['success' => false, 'message' => 'Unauthorized access']);
        }

        if ($this->request->getMethod() !== 'post') {
            return $this->response->setJSON(['success' => false, 'message' => 'Invalid request method']);
        }

        $data = [
            'member_name' => $this->request->getPost('member_name'),
            'father_name' => $this->request->getPost('father_name'),
            'cnic_no' => $this->request->getPost('cnic_no'),
            'cell_no' => $this->request->getPost('cell_no'),
            'user_id' => $this->request->getPost('user_id'),
            'status' => $this->request->getPost('status'),
        ];

        // Handle profile picture upload
        $profilePicture = $this->request->getFile('profile_picture');
        if ($profilePicture && $profilePicture->isValid() && !$profilePicture->hasMoved()) {
            $uploadPath = ROOTPATH . 'public/uploads/members';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0777, true);
            }
            
            $newName = $profilePicture->getRandomName();
            if ($profilePicture->move($uploadPath, $newName)) {
                $data['profile_picture'] = $newName;
            }
        }

        if ($this->memberModel->save($data)) {
            return $this->response->setJSON(['success' => true, 'message' => 'Member added successfully']);
        } else {
            return $this->response->setJSON(['success' => false, 'message' => 'Failed to add member']);
        }
    }

    public function updateMember($id = null)
    {
        if (!session()->get('logged_in') || !session()->get('is_admin')) {
            return $this->response->setJSON(['success' => false, 'message' => 'Unauthorized access']);
        }

        if (!$id || $this->request->getMethod() !== 'post') {
            return $this->response->setJSON(['success' => false, 'message' => 'Invalid request']);
        }

        $data = [
            'id' => $id,
            'member_name' => $this->request->getPost('member_name'),
            'father_name' => $this->request->getPost('father_name'),
            'cnic_no' => $this->request->getPost('cnic_no'),
            'cell_no' => $this->request->getPost('cell_no'),
            'status' => $this->request->getPost('status'),
        ];

        // Handle profile picture upload
        $profilePicture = $this->request->getFile('profile_picture');
        if ($profilePicture && $profilePicture->isValid() && !$profilePicture->hasMoved()) {
            $uploadPath = ROOTPATH . 'public/uploads/members';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0777, true);
            }
            
            $newName = $profilePicture->getRandomName();
            if ($profilePicture->move($uploadPath, $newName)) {
                $data['profile_picture'] = $newName;
            }
        }

        if ($this->memberModel->save($data)) {
            return $this->response->setJSON(['success' => true, 'message' => 'Member updated successfully']);
        } else {
            return $this->response->setJSON(['success' => false, 'message' => 'Failed to update member']);
        }
    }

    public function toggleMemberStatus($id = null, $status = null)
    {
        if (!session()->get('logged_in') || !session()->get('is_admin')) {
            return $this->response->setJSON(['success' => false, 'message' => 'Unauthorized access']);
        }

        if (!$id || !$status) {
            return $this->response->setJSON(['success' => false, 'message' => 'Invalid parameters']);
        }

        if ($this->memberModel->updateMemberStatus($id, $status)) {
            return $this->response->setJSON(['success' => true, 'message' => 'Member status updated successfully']);
        } else {
            return $this->response->setJSON(['success' => false, 'message' => 'Failed to update member status']);
        }
    }

    public function deleteMember($id = null)
    {
        if (!session()->get('logged_in') || !session()->get('is_admin')) {
            return $this->response->setJSON(['success' => false, 'message' => 'Unauthorized access']);
        }

        if (!$id) {
            return $this->response->setJSON(['success' => false, 'message' => 'Member ID is required']);
        }

        if ($this->memberModel->delete($id)) {
            return $this->response->setJSON(['success' => true, 'message' => 'Member deleted successfully']);
        } else {
            return $this->response->setJSON(['success' => false, 'message' => 'Failed to delete member']);
        }
    }
}
