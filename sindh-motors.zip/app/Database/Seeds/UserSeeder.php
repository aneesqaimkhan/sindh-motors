<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        $data = [
            'name' => 'Admin User',
            'fname' => 'Admin Father',
            'cnic_no' => '1234567890123',
            'cell_no' => '03001234567',
            'date_of_birth' => '1990-01-01',
            'category_id' => 1,
            'status' => 'active',
            'email' => 'admin@example.com',
            'username' => 'admin',
            'password' => password_hash('admin123', PASSWORD_DEFAULT),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ];

        $this->db->table('users')->insert($data);
    }
}
