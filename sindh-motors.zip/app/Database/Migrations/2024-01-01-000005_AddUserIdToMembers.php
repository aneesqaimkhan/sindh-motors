<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddUserIdToMembers extends Migration
{
    public function up()
    {
        $this->forge->addColumn('members', [
            'user_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
                'null'       => true,
            ],
        ]);

        // Add foreign key constraint
        $this->forge->addForeignKey('user_id', 'users', 'id', 'CASCADE', 'CASCADE');
    }

    public function down()
    {
        // Remove foreign key constraint first
        $this->db->query("ALTER TABLE members DROP FOREIGN KEY members_user_id_foreign");
        
        // Remove user_id column
        $this->forge->dropColumn('members', 'user_id');
    }
}
