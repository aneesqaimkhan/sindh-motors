<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class UpdateUsersTable extends Migration
{
    public function up()
    {
        // Add is_admin column
        $this->forge->addColumn('users', [
            'is_admin' => [
                'type'       => 'TINYINT',
                'constraint' => 1,
                'default'    => 0,
                'null'       => false,
            ],
        ]);

        // Update status enum to include 'pending'
        $this->db->query("ALTER TABLE users MODIFY COLUMN status ENUM('active', 'inactive', 'pending') DEFAULT 'pending'");
    }

    public function down()
    {
        // Remove is_admin column
        $this->forge->dropColumn('users', 'is_admin');
        
        // Revert status enum
        $this->db->query("ALTER TABLE users MODIFY COLUMN status ENUM('active', 'inactive') DEFAULT 'active'");
    }
}
