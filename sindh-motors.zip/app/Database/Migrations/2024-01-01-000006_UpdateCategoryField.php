<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class UpdateCategoryField extends Migration
{
    public function up()
    {
        // Update category_id field to VARCHAR to support string values
        $this->db->query("ALTER TABLE users MODIFY COLUMN category_id VARCHAR(50) NULL");
    }

    public function down()
    {
        // Revert back to INT
        $this->db->query("ALTER TABLE users MODIFY COLUMN category_id INT(11) NULL");
    }
}
