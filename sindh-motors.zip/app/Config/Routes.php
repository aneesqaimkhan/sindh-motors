<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('test', 'TestController::index');

// Auth routes
$routes->get('register', 'Auth::register');
$routes->post('register', 'Auth::register');
$routes->get('login', 'Auth::login');
$routes->post('login', 'Auth::login');
$routes->get('logout', 'Auth::logout');
$routes->get('dashboard', 'Auth::dashboard');

// Admin routes
$routes->group('admin', function($routes) {
    $routes->get('/', 'Admin::index');
    $routes->get('login', 'Auth::login');
    $routes->post('login', 'Auth::login');
    $routes->get('users', 'Admin::users');
    $routes->get('addUser', 'Admin::addUser');
    $routes->post('addUser', 'Admin::addUser');
    $routes->get('editUser/(:num)', 'Admin::editUser/$1');
    $routes->post('editUser/(:num)', 'Admin::editUser/$1');
    $routes->get('testEdit/(:num)', 'Admin::testEdit/$1');
    $routes->get('deleteUser/(:num)', 'Admin::deleteUser/$1');
    $routes->get('toggleStatus/(:num)', 'Admin::toggleStatus/$1');
    $routes->get('approve/(:num)', 'Admin::approveUser/$1');
    $routes->get('reject/(:num)', 'Admin::rejectUser/$1');
    $routes->get('user/(:num)', 'Admin::viewUserDetails/$1');
    $routes->get('pending', 'Admin::pendingUsers');
    
    // Membership Management Routes
    $routes->get('getMember/(:num)', 'Admin::getMember/$1');
    $routes->post('addMember', 'Admin::addMember');
    $routes->post('updateMember/(:num)', 'Admin::updateMember/$1');
    $routes->get('toggleMemberStatus/(:num)/(:any)', 'Admin::toggleMemberStatus/$1/$2');
    $routes->get('deleteMember/(:num)', 'Admin::deleteMember/$1');
});

// Members routes
$routes->group('members', function($routes) {
    $routes->get('/', 'Members::index');
    $routes->get('add', 'Members::add');
    $routes->post('add', 'Members::add');
    $routes->get('edit/(:num)', 'Members::edit/$1');
    $routes->post('edit/(:num)', 'Members::edit/$1');
    $routes->get('delete/(:num)', 'Members::delete/$1');
    $routes->get('toggleStatus/(:num)', 'Members::toggleStatus/$1');
    $routes->get('view/(:num)', 'Members::view/$1');
});
